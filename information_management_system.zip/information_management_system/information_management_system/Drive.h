#pragma once
class Drive
{
private:
	char Q;
public:
	Drive();
	void Set_Q(char q);

};

