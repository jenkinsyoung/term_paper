#include "Drive.h"
using namespace std;

Drive::Drive() :Q(0) {};
void Drive::Set_Q(char q) { Q = q; }